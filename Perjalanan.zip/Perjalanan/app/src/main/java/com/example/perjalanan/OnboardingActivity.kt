
package com.example.perjalanan

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.button.MaterialButton

class OnboardingActivity : AppCompatActivity() {

    private val pages = listOf(
        R.layout.page_onboarding_1,
        R.layout.page_onboarding_2,
        R.layout.page_onboarding_3
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        val pager = findViewById<ViewPager2>(R.id.pager)
        val btnNext = findViewById<MaterialButton>(R.id.btnNext)
        val tvSkip = findViewById<TextView>(R.id.tvSkip)

        val dots = listOf(
            R.id.dot1,
            R.id.dot2,
            R.id.dot3
        ).map { findViewById<View>(it) }

        pager.adapter = object : FragmentStateAdapter(this) {

            override fun getItemCount() = pages.size

            override fun createFragment(position: Int): Fragment {
                return OnboardingPageFragment.newInstance(
                    pages[position]
                )
            }
        }

        fun render(position: Int) {
            dots.forEachIndexed { index, dot ->
                dot.setBackgroundResource(
                    if (index == position) {
                        R.drawable.bg_dot_active
                    } else {
                        R.drawable.bg_dot_inactive
                    }
                )
            }

            val lastPage = position == pages.lastIndex

            btnNext.text = getString(
                if (lastPage) R.string.ob_start
                else R.string.ob_next
            )

            tvSkip.visibility = if (lastPage) {
                View.INVISIBLE
            } else {
                View.VISIBLE
            }
        }

        pager.registerOnPageChangeCallback(
            object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    render(position)
                }
            }
        )

        render(0)

        btnNext.setOnClickListener {
            if (pager.currentItem < pages.lastIndex) {
                pager.currentItem += 1
            } else {
                finishOnboarding()
            }
        }

        tvSkip.setOnClickListener {
            finishOnboarding()
        }
    }

    private fun finishOnboarding() {
        getSharedPreferences("settings", MODE_PRIVATE)
            .edit()
            .putBoolean("onboarding_done", true)
            .apply()

        startActivity(
            Intent(this, AuthActivity::class.java)
        )

        finish()
    }
}
