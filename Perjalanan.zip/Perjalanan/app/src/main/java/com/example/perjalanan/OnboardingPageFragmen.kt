package com.example.perjalanan

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.fragment.app.Fragment

class OnboardingPageFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val layout = requireArguments().getInt(ARG_LAYOUT)

        return inflater.inflate(
            layout,
            container,
            false
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val mascot = view.findViewById<com.airbnb.lottie.LottieAnimationView>(R.id.mascotAnimation)

        mascot?.let {
            it.setImageAssetsFolder("images/")
            it.playAnimation()
        }
    }

    companion object {
        private const val ARG_LAYOUT = "layout"

        fun newInstance(@LayoutRes layout: Int) =
            OnboardingPageFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_LAYOUT, layout)
                }
            }
    }
}